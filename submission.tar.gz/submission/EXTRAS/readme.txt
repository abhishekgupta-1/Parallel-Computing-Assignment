This directory contains non-blocking send and blocking send variants
